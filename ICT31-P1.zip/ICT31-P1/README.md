# ICT31-P1 (Bike Demo)

Two classes (`Bike`, `Bike1`) and a `Main` to show:
- `Bike`: no-arg constructor + setters
- `Bike1`: parameterized constructor

## Run
Use any IDE or `javac`:

```bash
javac -d out src/main/java/com/*.java src/main/java/mainpack/*.java
java -cp out mainpack.Main
```
